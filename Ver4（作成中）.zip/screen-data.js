// 画面遷移データ — admin.html の「💾 保存して反映」で自動更新されます。
// 画像は screen-images/ フォルダに実ファイルとして保存されています。
// 生成日時: 2026-08-07T08:38:07.583Z
window.APP_SCREEN_DATA = {
  "savedAt": "2026-08-07T08:38:07.583Z",
  "images": {},
  "patterns": [
    {
      "id": "scrl0vjcab",
      "name": "パターン1",
      "screens": []
    }
  ]
};
