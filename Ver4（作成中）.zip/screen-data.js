// 画面遷移データ — admin.html の「💾 保存して反映」で自動更新されます。
// 画像は screen-images/ フォルダに実ファイルとして保存されています。
// 生成日時: 2026-08-07T21:52:27.875Z
window.APP_SCREEN_DATA = {
  "savedAt": "2026-08-07T21:52:27.875Z",
  "images": {
    "lib0i67u0a7c": "screen-images/lib0i67u0a7c.png",
    "lib0yztshkgn": "screen-images/lib0yztshkgn.png",
    "lib1wljsh2al": "screen-images/lib1wljsh2al.png",
    "lib257f1nlda": "screen-images/lib257f1nlda.png",
    "lib27ftpxq2b": "screen-images/lib27ftpxq2b.png",
    "lib2u02e291w": "screen-images/lib2u02e291w.png",
    "lib2uekq0yvs": "screen-images/lib2uekq0yvs.png",
    "lib2x9p3bf7h": "screen-images/lib2x9p3bf7h.png",
    "lib654id1rps": "screen-images/lib654id1rps.png",
    "lib7hjs15yt5": "screen-images/lib7hjs15yt5.png",
    "lib7vf4n4wb2": "screen-images/lib7vf4n4wb2.png",
    "lib83extraey": "screen-images/lib83extraey.png",
    "lib85e1k1981": "screen-images/lib85e1k1981.png",
    "lib8bnjom0n3": "screen-images/lib8bnjom0n3.png",
    "lib97e2r7eg3": "screen-images/lib97e2r7eg3.png",
    "lib97jtwwlxs": "screen-images/lib97jtwwlxs.png",
    "lib9ezjvyx3w": "screen-images/lib9ezjvyx3w.png",
    "libasyn7vqu1": "screen-images/libasyn7vqu1.png",
    "libbm5p4njt6": "screen-images/libbm5p4njt6.png",
    "libeggractq2": "screen-images/libeggractq2.png",
    "libg6bncqkjb": "screen-images/libg6bncqkjb.png",
    "libgisfafhih": "screen-images/libgisfafhih.png",
    "libj69sz08xt": "screen-images/libj69sz08xt.png",
    "libl8fmlz5bo": "screen-images/libl8fmlz5bo.png",
    "liblf4z2s5pj": "screen-images/liblf4z2s5pj.png",
    "liblh5qehixk": "screen-images/liblh5qehixk.png",
    "libmxuniqoqb": "screen-images/libmxuniqoqb.png",
    "libnd1mbw9fm": "screen-images/libnd1mbw9fm.png",
    "libp5sjvxypo": "screen-images/libp5sjvxypo.png",
    "libpj1bvt40w": "screen-images/libpj1bvt40w.png",
    "libpl6rgz6dq": "screen-images/libpl6rgz6dq.png",
    "libqgv55pq2o": "screen-images/libqgv55pq2o.png",
    "libsbyb78n46": "screen-images/libsbyb78n46.png",
    "libskztn5gh9": "screen-images/libskztn5gh9.png",
    "libsp98ryf1a": "screen-images/libsp98ryf1a.png",
    "libtxfsh1j2y": "screen-images/libtxfsh1j2y.png",
    "libuk4ecppo6": "screen-images/libuk4ecppo6.png",
    "libw73u91z81": "screen-images/libw73u91z81.png",
    "libwrlpztu8n": "screen-images/libwrlpztu8n.png",
    "libwudw9o4ry": "screen-images/libwudw9o4ry.png",
    "libxdsml4fsq": "screen-images/libxdsml4fsq.png",
    "libxkq4ughb1": "screen-images/libxkq4ughb1.png",
    "libz2rvognj4": "screen-images/libz2rvognj4.png"
  },
  "patterns": [
    {
      "id": "scp672b83z",
      "name": "共通導線（世帯,事業,学校）",
      "screens": [
        {
          "id": "sc0nv5v6ck",
          "name": "スクリーンショット 2026-03-12 231411",
          "note": "",
          "imageSrc": "lib:lib2x9p3bf7h",
          "hotspots": []
        },
        {
          "id": "scv5nn129c",
          "name": "スクリーンショット 2026-03-15 105745",
          "note": "",
          "imageSrc": "lib:lib97e2r7eg3",
          "hotspots": []
        },
        {
          "id": "scosac7mll",
          "name": "スクリーンショット 2026-03-15 123938",
          "note": "",
          "imageSrc": "lib:lib2u02e291w",
          "hotspots": []
        },
        {
          "id": "sc6nrkk686",
          "name": "スクリーンショット 2026-03-17 231558",
          "note": "",
          "imageSrc": "lib:liblf4z2s5pj",
          "hotspots": []
        },
        {
          "id": "sc7v8m3oo7",
          "name": "スクリーンショット 2026-03-17 231641",
          "note": "",
          "imageSrc": "lib:lib257f1nlda",
          "hotspots": []
        },
        {
          "id": "scgwjhijjn",
          "name": "スクリーンショット 2026-03-18 235829",
          "note": "",
          "imageSrc": "lib:lib1wljsh2al",
          "hotspots": []
        },
        {
          "id": "scn784zf1u",
          "name": "スクリーンショット 2026-03-18 235837",
          "note": "",
          "imageSrc": "lib:lib654id1rps",
          "hotspots": []
        },
        {
          "id": "sc9ixsobzv",
          "name": "スクリーンショット 2026-03-19 000127",
          "note": "",
          "imageSrc": "lib:libpj1bvt40w",
          "hotspots": []
        },
        {
          "id": "sc2hopjc48",
          "name": "スクリーンショット 2026-03-19 201704",
          "note": "",
          "imageSrc": "lib:lib85e1k1981",
          "hotspots": []
        },
        {
          "id": "scu8u5hl2x",
          "name": "スクリーンショット 2026-03-19 201731",
          "note": "",
          "imageSrc": "lib:lib0yztshkgn",
          "hotspots": []
        },
        {
          "id": "sc1753j8mo",
          "name": "スクリーンショット 2026-03-24 225032",
          "note": "",
          "imageSrc": "lib:libasyn7vqu1",
          "hotspots": []
        },
        {
          "id": "scm6k0hcab",
          "name": "スクリーンショット 2026-03-25 073508",
          "note": "",
          "imageSrc": "lib:libgisfafhih",
          "hotspots": []
        },
        {
          "id": "scz91s18qg",
          "name": "スクリーンショット 2026-03-25 073518",
          "note": "",
          "imageSrc": "lib:libxkq4ughb1",
          "hotspots": []
        },
        {
          "id": "scac59in8z",
          "name": "スクリーンショット 2026-03-25 073538",
          "note": "",
          "imageSrc": "lib:lib97jtwwlxs",
          "hotspots": []
        },
        {
          "id": "scgugkefu7",
          "name": "スクリーンショット 2026-03-25 073627",
          "note": "",
          "imageSrc": "lib:lib7vf4n4wb2",
          "hotspots": []
        },
        {
          "id": "scewvcbizw",
          "name": "スクリーンショット 2026-03-28 210716",
          "note": "",
          "imageSrc": "lib:lib2uekq0yvs",
          "hotspots": []
        },
        {
          "id": "sck62l0yqq",
          "name": "スクリーンショット 2026-03-29 001725",
          "note": "",
          "imageSrc": "lib:libj69sz08xt",
          "hotspots": []
        },
        {
          "id": "scg6ma4fdd",
          "name": "スクリーンショット 2026-03-29 001925",
          "note": "",
          "imageSrc": "lib:liblh5qehixk",
          "hotspots": []
        },
        {
          "id": "scfao25cmo",
          "name": "スクリーンショット 2026-03-29 223540",
          "note": "",
          "imageSrc": "lib:libuk4ecppo6",
          "hotspots": []
        },
        {
          "id": "schdab6grf",
          "name": "スクリーンショット 2026-03-29 223547",
          "note": "",
          "imageSrc": "lib:libxdsml4fsq",
          "hotspots": []
        },
        {
          "id": "scx5ir43j6",
          "name": "スクリーンショット 2026-03-29 223549",
          "note": "",
          "imageSrc": "lib:libpl6rgz6dq",
          "hotspots": []
        },
        {
          "id": "scj4f82tos",
          "name": "スクリーンショット 2026-03-29 223551",
          "note": "",
          "imageSrc": "lib:lib8bnjom0n3",
          "hotspots": []
        },
        {
          "id": "sc45lw90hp",
          "name": "スクリーンショット 2026-03-29 223556",
          "note": "",
          "imageSrc": "lib:lib9ezjvyx3w",
          "hotspots": []
        },
        {
          "id": "scw6pe3udv",
          "name": "スクリーンショット 2026-03-29 223558",
          "note": "",
          "imageSrc": "lib:lib7hjs15yt5",
          "hotspots": []
        },
        {
          "id": "scgjrpc162",
          "name": "スクリーンショット 2026-03-29 223600",
          "note": "",
          "imageSrc": "lib:libwrlpztu8n",
          "hotspots": []
        },
        {
          "id": "scsc4dnlh5",
          "name": "スクリーンショット 2026-03-29 223632",
          "note": "",
          "imageSrc": "lib:libbm5p4njt6",
          "hotspots": []
        },
        {
          "id": "sczvt9icu8",
          "name": "スクリーンショット 2026-03-29 223638",
          "note": "",
          "imageSrc": "lib:libl8fmlz5bo",
          "hotspots": []
        },
        {
          "id": "scs6vimyut",
          "name": "スクリーンショット 2026-03-29 223641",
          "note": "",
          "imageSrc": "lib:libqgv55pq2o",
          "hotspots": []
        },
        {
          "id": "sc78nausmu",
          "name": "スクリーンショット 2026-03-29 223644",
          "note": "",
          "imageSrc": "lib:libz2rvognj4",
          "hotspots": []
        },
        {
          "id": "sc8urn565w",
          "name": "スクリーンショット 2026-03-29 223647",
          "note": "",
          "imageSrc": "lib:libnd1mbw9fm",
          "hotspots": []
        },
        {
          "id": "sc8kbuy7we",
          "name": "スクリーンショット 2026-03-29 223649",
          "note": "",
          "imageSrc": "lib:libsbyb78n46",
          "hotspots": []
        },
        {
          "id": "sc1kucjyed",
          "name": "スクリーンショット 2026-03-29 223652",
          "note": "",
          "imageSrc": "lib:libw73u91z81",
          "hotspots": []
        },
        {
          "id": "scitoneojl",
          "name": "スクリーンショット 2026-03-29 223905",
          "note": "",
          "imageSrc": "lib:libtxfsh1j2y",
          "hotspots": []
        },
        {
          "id": "scakjbtcd6",
          "name": "スクリーンショット 2026-06-04 234441",
          "note": "",
          "imageSrc": "lib:libp5sjvxypo",
          "hotspots": []
        },
        {
          "id": "scs8oghqd6",
          "name": "スクリーンショット 2026-06-04 234500",
          "note": "",
          "imageSrc": "lib:libmxuniqoqb",
          "hotspots": []
        },
        {
          "id": "sccuae2hsl",
          "name": "スクリーンショット 2026-06-04 234530",
          "note": "",
          "imageSrc": "lib:libeggractq2",
          "hotspots": []
        },
        {
          "id": "scd4dor3qi",
          "name": "スクリーンショット 2026-06-10 234237",
          "note": "",
          "imageSrc": "lib:lib0i67u0a7c",
          "hotspots": []
        },
        {
          "id": "scl81hovpg",
          "name": "スクリーンショット 2026-07-19 224310",
          "note": "",
          "imageSrc": "lib:lib27ftpxq2b",
          "hotspots": []
        },
        {
          "id": "sc5s1nl1y7",
          "name": "スクリーンショット 2026-07-19 232323",
          "note": "",
          "imageSrc": "lib:libg6bncqkjb",
          "hotspots": []
        },
        {
          "id": "scf8tpazwg",
          "name": "スクリーンショット 2026-07-22 011343",
          "note": "",
          "imageSrc": "lib:lib83extraey",
          "hotspots": []
        },
        {
          "id": "scnj1z8lzy",
          "name": "スクリーンショット 2026-07-22 011554",
          "note": "",
          "imageSrc": "lib:libsp98ryf1a",
          "hotspots": []
        },
        {
          "id": "sc3fjwtnbf",
          "name": "スクリーンショット 2026-07-22 225139",
          "note": "",
          "imageSrc": "lib:libwudw9o4ry",
          "hotspots": []
        },
        {
          "id": "scbgitdjti",
          "name": "スクリーンショット 2026-07-22 225152",
          "note": "",
          "imageSrc": "lib:libskztn5gh9",
          "hotspots": []
        }
      ]
    },
    {
      "id": "sclza3g28e",
      "name": "世帯",
      "screens": []
    },
    {
      "id": "scgjqm2nnw",
      "name": "事業",
      "screens": []
    },
    {
      "id": "scgtcopx9l",
      "name": "学校",
      "screens": []
    },
    {
      "id": "scieu46j8x",
      "name": "アプリ起点の登録導線",
      "screens": [],
      "color": "#f15bb5"
    },
    {
      "id": "scqiuryris",
      "name": "ログイン不可",
      "screens": [],
      "color": "#2ec4b6"
    },
    {
      "id": "scx8s8svke",
      "name": "TVアプリの利用",
      "screens": [],
      "color": "#2ec4b6"
    },
    {
      "id": "scf4cmccnn",
      "name": "アカウント設定のあれこれ",
      "screens": [],
      "color": "#4361ee"
    },
    {
      "id": "scdpmtby7v",
      "name": "一時的な地域の変更",
      "screens": [],
      "color": "#9b5de5"
    },
    {
      "id": "scyrnfmdk2",
      "name": "解約",
      "screens": [],
      "color": "#2ec4b6"
    },
    {
      "id": "scjtfjyfin",
      "name": "受信料アカウントとの連携解除",
      "screens": [],
      "color": "#e84393"
    },
    {
      "id": "scv2evle6r",
      "name": "ホワイトリスト",
      "screens": [],
      "color": "#2ed573"
    }
  ]
};
