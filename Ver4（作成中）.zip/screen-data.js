// 画面遷移データ — admin.html の「💾 保存して反映」で自動更新されます。
// 画像は screen-images/ フォルダに実ファイルとして保存されています。
// 生成日時: 2026-08-07T15:05:07.569Z
window.APP_SCREEN_DATA = {
  "savedAt": "2026-08-07T15:05:07.569Z",
  "images": {},
  "patterns": [
    {
      "id": "scp672b83z",
      "name": "共通導線（世帯,事業,学校）",
      "screens": []
    },
    {
      "id": "sclza3g28e",
      "name": "世帯",
      "screens": []
    },
    {
      "id": "scgjqm2nnw",
      "name": "事業",
      "screens": []
    },
    {
      "id": "scgtcopx9l",
      "name": "学校",
      "screens": []
    },
    {
      "id": "scieu46j8x",
      "name": "アプリ起点の登録導線",
      "screens": [],
      "color": "#f15bb5"
    },
    {
      "id": "scqiuryris",
      "name": "ログイン不可",
      "screens": [],
      "color": "#2ec4b6"
    },
    {
      "id": "scx8s8svke",
      "name": "TVアプリの利用",
      "screens": [],
      "color": "#2ec4b6"
    },
    {
      "id": "scf4cmccnn",
      "name": "アカウント設定のあれこれ",
      "screens": [],
      "color": "#4361ee"
    },
    {
      "id": "scdpmtby7v",
      "name": "一時的な地域の変更",
      "screens": [],
      "color": "#9b5de5"
    },
    {
      "id": "scyrnfmdk2",
      "name": "解約",
      "screens": [],
      "color": "#2ec4b6"
    },
    {
      "id": "scjtfjyfin",
      "name": "受信料アカウントとの連携解除",
      "screens": [],
      "color": "#e84393"
    },
    {
      "id": "scv2evle6r",
      "name": "ホワイトリスト",
      "screens": [],
      "color": "#2ed573"
    }
  ]
};
