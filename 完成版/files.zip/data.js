// ツール設定ファイル — サイドメニュー・添付ファイル・ヒアリング・更新履歴・固定テキスト
// =============================================================================
// 【管理方法】
//   admin.html の各タブ「💾 保存して反映」を押すと data.js がダウンロードされます。
//   ダウンロードした data.js を index.html / script.html 等と同じフォルダに
//   上書き配置してください。次回ページ読み込み時から設定が反映されます。
//
// 【データ区分】
//   このファイル (data.js)  … サイドメニュー・添付ファイル・ヒアリング・更新履歴・固定テキスト
//   YYYY-MM-DD.json         … トークスクリプト・メールテンプレート・画面遷移フロー
// =============================================================================

window.APP_STATIC_DATA = {
  "generatedAt": "初期ファイル（admin.html で保存すると上書きされます）",

  // null のキーは common-utils.js の内蔵デフォルトを使用します
  "sideMenuData":     null,
  "sideMenuFiles":    {},
  "hearingQuestions": null,
  "hearingPolicies":  null,
  "hearingPatterns":  null,
  "updateHistory":    null,
  "fixedTexts":       null
};
